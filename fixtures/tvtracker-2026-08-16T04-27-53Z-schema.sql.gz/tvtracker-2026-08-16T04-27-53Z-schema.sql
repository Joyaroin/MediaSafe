


SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;


COMMENT ON SCHEMA "public" IS 'standard public schema';



CREATE EXTENSION IF NOT EXISTS "pg_stat_statements" WITH SCHEMA "extensions";






CREATE EXTENSION IF NOT EXISTS "pgcrypto" WITH SCHEMA "extensions";






CREATE EXTENSION IF NOT EXISTS "supabase_vault" WITH SCHEMA "vault";






CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA "extensions";






CREATE OR REPLACE FUNCTION "public"."set_updated_at"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
begin
  new.updated_at = now();
  return new;
end;
$$;


ALTER FUNCTION "public"."set_updated_at"() OWNER TO "postgres";

SET default_tablespace = '';

SET default_table_access_method = "heap";


CREATE TABLE IF NOT EXISTS "public"."episode_overrides" (
    "user_id" "uuid" NOT NULL,
    "show_id" "uuid" NOT NULL,
    "season_number" integer NOT NULL,
    "episode_number" integer NOT NULL,
    "watched" boolean NOT NULL,
    "watched_at" timestamp with time zone
);


ALTER TABLE "public"."episode_overrides" OWNER TO "postgres";


COMMENT ON TABLE "public"."episode_overrides" IS 'Per-episode exceptions layered on top of shows.watched_through — packages/shared''s episode model (S3) resolves the two into a watched/unwatched state. RLS below is a backstop only, same caveat as shows.';



CREATE TABLE IF NOT EXISTS "public"."list_items" (
    "list_id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "show_id" "uuid",
    "movie_id" "uuid",
    "added_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "list_items_one_target" CHECK (("num_nonnulls"("show_id", "movie_id") = 1))
);


ALTER TABLE "public"."list_items" OWNER TO "postgres";


COMMENT ON TABLE "public"."list_items" IS 'Membership rows linking a list to a show or a movie (never both — list_items_one_target). RLS below is a backstop only, same caveat as shows.';



CREATE TABLE IF NOT EXISTS "public"."lists" (
    "id" "uuid" DEFAULT "extensions"."gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "name" "text" NOT NULL,
    "kind" "text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "description" "text" DEFAULT ''::"text" NOT NULL,
    "grid_size" "text" DEFAULT 'medium'::"text" NOT NULL,
    CONSTRAINT "lists_grid_size_check" CHECK (("grid_size" = ANY (ARRAY['small'::"text", 'medium'::"text", 'large'::"text"]))),
    CONSTRAINT "lists_kind_check" CHECK (("kind" = ANY (ARRAY['tv'::"text", 'movie'::"text"])))
);


ALTER TABLE "public"."lists" OWNER TO "postgres";


COMMENT ON TABLE "public"."lists" IS 'One row per custom list a user has created. RLS below is a backstop only, same caveat as shows: the Worker connects through Hyperdrive as the table owner and bypasses RLS entirely, and authorization is enforced in application code via the user_id filter every repository query applies (see /CLAUDE.md and plan.md §3.4).';



COMMENT ON COLUMN "public"."lists"."description" IS 'Free text the user writes about a list. Empty string means none — never null (#159).';



COMMENT ON COLUMN "public"."lists"."grid_size" IS 'How densely the list screen renders its items: small | medium | large, defaulting to medium, matching the three values ~/MyTVTracker offers (#159).';



CREATE TABLE IF NOT EXISTS "public"."movies" (
    "id" "uuid" DEFAULT "extensions"."gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "tmdb_id" integer NOT NULL,
    "title" "text" DEFAULT ''::"text" NOT NULL,
    "overview" "text" DEFAULT ''::"text" NOT NULL,
    "poster_path" "text",
    "backdrop_path" "text",
    "release_date" "date",
    "runtime_minutes" integer,
    "watch_status" "text" DEFAULT 'Plan to Watch'::"text" NOT NULL,
    "is_watched" boolean DEFAULT false NOT NULL,
    "watched_at" timestamp with time zone,
    "watch_count" integer DEFAULT 0 NOT NULL,
    "is_favourite" boolean DEFAULT false NOT NULL,
    "is_pinned" boolean DEFAULT false NOT NULL,
    "added_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "legacy" "jsonb" DEFAULT '{}'::"jsonb" NOT NULL,
    CONSTRAINT "movies_watch_count_check" CHECK (("watch_count" >= 0)),
    CONSTRAINT "movies_watch_status_check" CHECK (("watch_status" = ANY (ARRAY['Plan to Watch'::"text", 'Watching'::"text", 'Completed'::"text", 'Paused'::"text"])))
);


ALTER TABLE "public"."movies" OWNER TO "postgres";


COMMENT ON TABLE "public"."movies" IS 'One row per movie a user has added. RLS below is a backstop only, same caveat as shows.';



CREATE TABLE IF NOT EXISTS "public"."shows" (
    "id" "uuid" DEFAULT "extensions"."gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "tmdb_id" integer NOT NULL,
    "name" "text" DEFAULT ''::"text" NOT NULL,
    "overview" "text" DEFAULT ''::"text" NOT NULL,
    "original_name" "text",
    "poster_path" "text",
    "backdrop_path" "text",
    "first_air_date" "date",
    "tmdb_status" "text",
    "total_episodes" integer DEFAULT 0 NOT NULL,
    "episode_runtime" integer,
    "watch_status" "text" DEFAULT 'Plan to Watch'::"text" NOT NULL,
    "watched_through" integer DEFAULT 0 NOT NULL,
    "watched_count" integer DEFAULT 0 NOT NULL,
    "is_favourite" boolean DEFAULT false NOT NULL,
    "is_pinned" boolean DEFAULT false NOT NULL,
    "added_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "last_watched_at" timestamp with time zone,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "legacy" "jsonb" DEFAULT '{}'::"jsonb" NOT NULL,
    CONSTRAINT "shows_counts_nonneg" CHECK ((("total_episodes" >= 0) AND ("watched_through" >= 0) AND ("watched_count" >= 0))),
    CONSTRAINT "shows_watch_status_check" CHECK (("watch_status" = ANY (ARRAY['Plan to Watch'::"text", 'Watching'::"text", 'Completed'::"text", 'Paused'::"text"])))
);


ALTER TABLE "public"."shows" OWNER TO "postgres";


COMMENT ON TABLE "public"."shows" IS 'One row per show a user has added. RLS is enabled below but is a backstop only: the Worker connects through Hyperdrive as the table owner and bypasses RLS entirely. Authorization is enforced in application code via the user_id filter every repository query applies — see /CLAUDE.md and plan.md §3.1.';



CREATE TABLE IF NOT EXISTS "public"."watch_events" (
    "id" "uuid" DEFAULT "extensions"."gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "show_id" "uuid",
    "movie_id" "uuid",
    "season_number" integer,
    "episode_number" integer,
    "watched_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "watch_events_episode_shape" CHECK (((("show_id" IS NOT NULL) AND ("season_number" IS NOT NULL) AND ("episode_number" IS NOT NULL)) OR (("movie_id" IS NOT NULL) AND ("season_number" IS NULL) AND ("episode_number" IS NULL)))),
    CONSTRAINT "watch_events_one_target" CHECK (("num_nonnulls"("show_id", "movie_id") = 1))
);


ALTER TABLE "public"."watch_events" OWNER TO "postgres";


COMMENT ON TABLE "public"."watch_events" IS 'Append-only history: one row per watch. Activity, streaks, per-episode watch counts and rewatch totals are all derived from this table and stored nowhere else (ADR-0003). RLS below is a backstop only, same caveat as shows: the Worker connects through Hyperdrive as owner and authorization is enforced in application code via the user_id filter every query applies.';



ALTER TABLE ONLY "public"."episode_overrides"
    ADD CONSTRAINT "episode_overrides_pkey" PRIMARY KEY ("show_id", "season_number", "episode_number");



ALTER TABLE ONLY "public"."lists"
    ADD CONSTRAINT "lists_id_user_id_key" UNIQUE ("id", "user_id");



ALTER TABLE ONLY "public"."lists"
    ADD CONSTRAINT "lists_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."movies"
    ADD CONSTRAINT "movies_id_user_id_key" UNIQUE ("id", "user_id");



ALTER TABLE ONLY "public"."movies"
    ADD CONSTRAINT "movies_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."movies"
    ADD CONSTRAINT "movies_user_id_tmdb_id_key" UNIQUE ("user_id", "tmdb_id");



ALTER TABLE ONLY "public"."shows"
    ADD CONSTRAINT "shows_id_user_id_key" UNIQUE ("id", "user_id");



ALTER TABLE ONLY "public"."shows"
    ADD CONSTRAINT "shows_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."shows"
    ADD CONSTRAINT "shows_user_id_tmdb_id_key" UNIQUE ("user_id", "tmdb_id");



ALTER TABLE ONLY "public"."watch_events"
    ADD CONSTRAINT "watch_events_pkey" PRIMARY KEY ("id");



CREATE INDEX "episode_overrides_user_id_show_id_idx" ON "public"."episode_overrides" USING "btree" ("user_id", "show_id");



CREATE UNIQUE INDEX "list_items_movie_idx" ON "public"."list_items" USING "btree" ("list_id", "movie_id") WHERE ("movie_id" IS NOT NULL);



CREATE UNIQUE INDEX "list_items_show_idx" ON "public"."list_items" USING "btree" ("list_id", "show_id") WHERE ("show_id" IS NOT NULL);



CREATE INDEX "list_items_user_list_idx" ON "public"."list_items" USING "btree" ("user_id", "list_id");



CREATE UNIQUE INDEX "lists_user_kind_name_ci_idx" ON "public"."lists" USING "btree" ("user_id", "kind", "lower"("name"));



CREATE INDEX "watch_events_user_movie_idx" ON "public"."watch_events" USING "btree" ("user_id", "movie_id") WHERE ("movie_id" IS NOT NULL);



CREATE INDEX "watch_events_user_show_idx" ON "public"."watch_events" USING "btree" ("user_id", "show_id") WHERE ("show_id" IS NOT NULL);



CREATE INDEX "watch_events_user_watched_at_idx" ON "public"."watch_events" USING "btree" ("user_id", "watched_at" DESC);



CREATE OR REPLACE TRIGGER "lists_set_updated_at" BEFORE UPDATE ON "public"."lists" FOR EACH ROW EXECUTE FUNCTION "public"."set_updated_at"();



CREATE OR REPLACE TRIGGER "movies_set_updated_at" BEFORE UPDATE ON "public"."movies" FOR EACH ROW EXECUTE FUNCTION "public"."set_updated_at"();



CREATE OR REPLACE TRIGGER "shows_set_updated_at" BEFORE UPDATE ON "public"."shows" FOR EACH ROW EXECUTE FUNCTION "public"."set_updated_at"();



ALTER TABLE ONLY "public"."episode_overrides"
    ADD CONSTRAINT "episode_overrides_show_id_user_id_fkey" FOREIGN KEY ("show_id", "user_id") REFERENCES "public"."shows"("id", "user_id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."list_items"
    ADD CONSTRAINT "list_items_list_id_user_id_fkey" FOREIGN KEY ("list_id", "user_id") REFERENCES "public"."lists"("id", "user_id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."list_items"
    ADD CONSTRAINT "list_items_movie_id_user_id_fkey" FOREIGN KEY ("movie_id", "user_id") REFERENCES "public"."movies"("id", "user_id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."list_items"
    ADD CONSTRAINT "list_items_show_id_user_id_fkey" FOREIGN KEY ("show_id", "user_id") REFERENCES "public"."shows"("id", "user_id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."lists"
    ADD CONSTRAINT "lists_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."movies"
    ADD CONSTRAINT "movies_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."shows"
    ADD CONSTRAINT "shows_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."watch_events"
    ADD CONSTRAINT "watch_events_movie_id_user_id_fkey" FOREIGN KEY ("movie_id", "user_id") REFERENCES "public"."movies"("id", "user_id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."watch_events"
    ADD CONSTRAINT "watch_events_show_id_user_id_fkey" FOREIGN KEY ("show_id", "user_id") REFERENCES "public"."shows"("id", "user_id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."watch_events"
    ADD CONSTRAINT "watch_events_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;



ALTER TABLE "public"."episode_overrides" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "episode_overrides_delete_own" ON "public"."episode_overrides" FOR DELETE USING (("auth"."uid"() = "user_id"));



CREATE POLICY "episode_overrides_insert_own" ON "public"."episode_overrides" FOR INSERT WITH CHECK (("auth"."uid"() = "user_id"));



CREATE POLICY "episode_overrides_select_own" ON "public"."episode_overrides" FOR SELECT USING (("auth"."uid"() = "user_id"));



CREATE POLICY "episode_overrides_update_own" ON "public"."episode_overrides" FOR UPDATE USING (("auth"."uid"() = "user_id")) WITH CHECK (("auth"."uid"() = "user_id"));



ALTER TABLE "public"."list_items" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "list_items_delete_own" ON "public"."list_items" FOR DELETE USING (("auth"."uid"() = "user_id"));



CREATE POLICY "list_items_insert_own" ON "public"."list_items" FOR INSERT WITH CHECK (("auth"."uid"() = "user_id"));



CREATE POLICY "list_items_select_own" ON "public"."list_items" FOR SELECT USING (("auth"."uid"() = "user_id"));



CREATE POLICY "list_items_update_own" ON "public"."list_items" FOR UPDATE USING (("auth"."uid"() = "user_id")) WITH CHECK (("auth"."uid"() = "user_id"));



ALTER TABLE "public"."lists" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "lists_delete_own" ON "public"."lists" FOR DELETE USING (("auth"."uid"() = "user_id"));



CREATE POLICY "lists_insert_own" ON "public"."lists" FOR INSERT WITH CHECK (("auth"."uid"() = "user_id"));



CREATE POLICY "lists_select_own" ON "public"."lists" FOR SELECT USING (("auth"."uid"() = "user_id"));



CREATE POLICY "lists_update_own" ON "public"."lists" FOR UPDATE USING (("auth"."uid"() = "user_id")) WITH CHECK (("auth"."uid"() = "user_id"));



ALTER TABLE "public"."movies" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "movies_delete_own" ON "public"."movies" FOR DELETE USING (("auth"."uid"() = "user_id"));



CREATE POLICY "movies_insert_own" ON "public"."movies" FOR INSERT WITH CHECK (("auth"."uid"() = "user_id"));



CREATE POLICY "movies_select_own" ON "public"."movies" FOR SELECT USING (("auth"."uid"() = "user_id"));



CREATE POLICY "movies_update_own" ON "public"."movies" FOR UPDATE USING (("auth"."uid"() = "user_id")) WITH CHECK (("auth"."uid"() = "user_id"));



ALTER TABLE "public"."shows" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "shows_delete_own" ON "public"."shows" FOR DELETE USING (("auth"."uid"() = "user_id"));



CREATE POLICY "shows_insert_own" ON "public"."shows" FOR INSERT WITH CHECK (("auth"."uid"() = "user_id"));



CREATE POLICY "shows_select_own" ON "public"."shows" FOR SELECT USING (("auth"."uid"() = "user_id"));



CREATE POLICY "shows_update_own" ON "public"."shows" FOR UPDATE USING (("auth"."uid"() = "user_id")) WITH CHECK (("auth"."uid"() = "user_id"));



ALTER TABLE "public"."watch_events" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "watch_events are the owner's own" ON "public"."watch_events" USING (("auth"."uid"() = "user_id")) WITH CHECK (("auth"."uid"() = "user_id"));





ALTER PUBLICATION "supabase_realtime" OWNER TO "postgres";


GRANT USAGE ON SCHEMA "public" TO "postgres";
GRANT USAGE ON SCHEMA "public" TO "anon";
GRANT USAGE ON SCHEMA "public" TO "authenticated";
GRANT USAGE ON SCHEMA "public" TO "service_role";






















































































































































GRANT ALL ON FUNCTION "public"."set_updated_at"() TO "anon";
GRANT ALL ON FUNCTION "public"."set_updated_at"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."set_updated_at"() TO "service_role";


















GRANT ALL ON TABLE "public"."episode_overrides" TO "anon";
GRANT ALL ON TABLE "public"."episode_overrides" TO "authenticated";
GRANT ALL ON TABLE "public"."episode_overrides" TO "service_role";



GRANT ALL ON TABLE "public"."list_items" TO "anon";
GRANT ALL ON TABLE "public"."list_items" TO "authenticated";
GRANT ALL ON TABLE "public"."list_items" TO "service_role";



GRANT ALL ON TABLE "public"."lists" TO "anon";
GRANT ALL ON TABLE "public"."lists" TO "authenticated";
GRANT ALL ON TABLE "public"."lists" TO "service_role";



GRANT ALL ON TABLE "public"."movies" TO "anon";
GRANT ALL ON TABLE "public"."movies" TO "authenticated";
GRANT ALL ON TABLE "public"."movies" TO "service_role";



GRANT ALL ON TABLE "public"."shows" TO "anon";
GRANT ALL ON TABLE "public"."shows" TO "authenticated";
GRANT ALL ON TABLE "public"."shows" TO "service_role";



GRANT ALL ON TABLE "public"."watch_events" TO "anon";
GRANT ALL ON TABLE "public"."watch_events" TO "authenticated";
GRANT ALL ON TABLE "public"."watch_events" TO "service_role";









ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "service_role";






ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "service_role";






ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "service_role";































